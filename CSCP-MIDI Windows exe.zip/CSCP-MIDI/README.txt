# CSCP-MIDI (Packaged as a Windows .exe)
# Provides two-way connection and communications between CSCP and MIDI devices.
# Copyright Peter Walker 2020.
# Feedback/Requests - peter.allan.walker@gmail.com

# Unzip the CSCP-MIDI.zip file and Keep all of the files in the unzipped folder together. 
# Create a shortcut to the CSCP_MIDI.exe file to run the application.


Usage:

The following instructions relate to Calrec Brio & Summa mixers. For other Calrec mixer types, please refer to their installation manual for configuring CSCP.

Connect one of the LAN ports on your Calrec Audio mixer to your PC (or to the same network your PC is on).

Go to System-Settings>LAN config and set the mixer's IP address to one that is reachable from your PC (and set a static IP address on your PC if necessary).

Go to System-Settings>Control-Protocols, check/set the TCP Port the mixer is using for CSCP and ensure CSCP is set to enabled.

If using a physical controller, its midi port will automatically be available to select from the CSCP-MIDI application if the controller is connected when CSCP-MIDI starts up.

CSCP-MIDI has been tested with the KorgNanoKontrol2
To use in its' default "CC" mode, selectable on the controller by holding its SET MARKER & CYCLE buttons when connecting it to your PC.
To use in "Sonar" mode, hold the SET MARKER & RECORD buttons when connecting.
To request support for other MIDI modes, contact peter.allan.walker@gmail.com
If using DAW software running on the same PC as this application on Windows, then 3rd party software is required to provide virtual midi ports (to allow midi comms between applications running in Windows)

Download loopmidi by Tobias Erichsen. Open loopmidi and click the '+' button to add a MIDI port that will be accessible to your DAW and to CSCP-MIDI.

Configure your DAW for use with a MIDI controller, selecting the MIDI port/s created by loopmidi.

CSCP-MIDI has been tested with the Reaper DAW:
Reaper>Options>Preferences>Control-Surfaces, select "Add", choose "Makie Control Universal" and select the midi ports created by loopmidi. Note, It is best to configure two MIDI ports in loop midi, one for input and one for output to avoid feedback loops. Ensure you select the correct ports here and in CSCP-MIDI when it starts.
Also in preferences, select Audio>MIDI-Devices and enable the MIDI I/O created from loopmidi.
Start CSCP-MIDI using python cscp-midi.py or running the .exe. If it has been run before, you will be presented with the last used settings. If you need to change the settings press 'n' and enter the mixer's IP address, CSCP port, the MIDI ports you are using and the MIDI mode...

You now have two-way comms between your Calrec mixer and your MIDI device/DAW!